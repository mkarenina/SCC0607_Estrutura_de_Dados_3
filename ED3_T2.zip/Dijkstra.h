#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include "Global.h"


void Dijkstra(char origem[], char destino[], vertice *vet[], int total_vertices);

#endif